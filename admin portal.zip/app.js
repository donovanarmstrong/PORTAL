const loginButton = document.getElementById("login-button");

loginButton.addEventListener("click", function(event) {
  event.preventDefault();

  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  // Send username and password to server for verification
  // This is just an example and should be replaced with actual code
  if (username === "admin" && password === "password") {
    window.location.href = "admin-dashboard.html";
  } else {
    const errorMessage = document.getElementById("error-message");
    errorMessage.innerHTML = "Invalid username or password";
  }
});
